<?php
use Core\Database;
use Core\Validator;

header('Content-Type: application/json'); // Set response header for JSON

$config = require base_path('config.php');
$db = new Database($config['database']);

$group_name = $_POST['group_name'] ?? '';

if (empty($group_name)) {
    echo json_encode([
        'success' => false,
        'message' => 'Group name is required'
    ]);
    exit;
}

try {
    $db->query("INSERT INTO expense_categories (name) VALUES (:name)", [
        ':name' => $group_name,
    ]);

    echo json_encode([
        'success' => true,
        'message' => 'Group added successfully'
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error adding group: ' . $e->getMessage()
    ]);
}

exit;
