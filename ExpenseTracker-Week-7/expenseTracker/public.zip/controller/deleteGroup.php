<?php
use Core\Database;
require base_path('Core/Database.php');
$config = require base_path('config.php');
$db = new Database($config['database']);

// Ensure 'id' is set before using it
if (!isset($_POST['id'])) {
    die("Error: ID not provided");
}

// Delete the group
try {
    $result = $db->query('DELETE FROM expense_categories WHERE id = :id', ['id' => $_POST['id']]);
} catch (PDOException $e) {
    error_log("Error deleting group: " . $e->getMessage());
    die("Error deleting group.");
}

// Check if deletion was successful
if ($result->rowCount() === 0) {
    error_log("Error: No group found with the provided ID.");
    die("Error: No group found with the provided ID.");
}

// Redirect back to home
header('Location: /');
exit();